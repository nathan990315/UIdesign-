package com.eveningoutpost.dexdrip.tidepool;

public class MGetDatasetsRequest extends BaseMessage {
}
