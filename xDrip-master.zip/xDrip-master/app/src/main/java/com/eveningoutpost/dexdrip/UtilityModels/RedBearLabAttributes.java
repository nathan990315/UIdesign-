package com.eveningoutpost.dexdrip.UtilityModels;

import java.util.UUID;

/**
 * Created by Emma Black on 2/21/15.
 */
public class RedBearLabAttributes {
    public static UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public static UUID REDBEARLAB_SERVICE =  UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    public static UUID REDBEARLAB_TX =  UUID.fromString("713d0002-503e-4c75-ba94-3148f18d941e");
}
