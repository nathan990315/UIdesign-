package com.eveningoutpost.dexdrip.Models;

/**
 * Created by jamorham on 04/01/16.
 */
public class CobCalc {
    double initialCarbs;
    double decayedBy;
    double isDecaying;
    double carbTime;
}
