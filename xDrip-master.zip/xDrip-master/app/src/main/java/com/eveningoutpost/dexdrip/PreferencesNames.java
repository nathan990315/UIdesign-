package com.eveningoutpost.dexdrip;

/**
 * Created by jamorham on 11/01/16.
 */
public class PreferencesNames {

    public static final String SENT_TOKEN_TO_SERVER = "GCMsentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "GCMregistrationComplete";
    public static final String SYNC_VERSION = "1";
}
