package com.eveningoutpost.dexdrip.tidepool;

import java.util.List;

public class MUploadReply {

    List<String> data;

}
