package com.eveningoutpost.dexdrip.G5Model;

/**
 * Created by joeginley on 3/19/16.
 */
public class Transmitter {
    public String transmitterId = "";

    public Transmitter(String id) {
        transmitterId = id;
    }

    public void authenticate() {

    }
}
