package com.eveningoutpost.dexdrip.stats;

/**
 * Created by adrian on 03/07/15.
 */
public class BgReadingStats {
    public long timestamp;
    public double calculated_value;
}