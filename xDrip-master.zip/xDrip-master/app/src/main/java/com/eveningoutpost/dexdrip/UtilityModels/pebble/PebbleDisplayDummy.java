package com.eveningoutpost.dexdrip.UtilityModels.pebble;

import com.getpebble.android.kit.util.PebbleDictionary;

/**
 * Created by andy on 02/06/16.
 */
public class PebbleDisplayDummy extends PebbleDisplayAbstract {

    @Override
    public void startDeviceCommand() {
    }

    @Override
    public void receiveData(int transactionId, PebbleDictionary data) {
    }

}
