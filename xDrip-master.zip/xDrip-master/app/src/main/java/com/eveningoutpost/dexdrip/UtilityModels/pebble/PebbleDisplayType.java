package com.eveningoutpost.dexdrip.UtilityModels.pebble;

/**
 * Created by andy on 01/06/16.
 */
public enum PebbleDisplayType {

    None,
    Standard,
    Trend,
    TrendClassic,
    TrendClay;

}
