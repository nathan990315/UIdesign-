ALTER TABLE Sensors ADD COLUMN sensor_location TEXT;
