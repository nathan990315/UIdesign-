ALTER TABLE Calibration ADD COLUMN possible_bad BOOLEAN;
