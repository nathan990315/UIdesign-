ALTER TABLE BgReadings ADD COLUMN raw_calculated REAL;
