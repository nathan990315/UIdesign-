ALTER TABLE Calibration ADD COLUMN first_decay REAL;
ALTER TABLE Calibration ADD COLUMN second_decay REAL;
ALTER TABLE Calibration ADD COLUMN first_slope REAL;
ALTER TABLE Calibration ADD COLUMN second_slope REAL;
