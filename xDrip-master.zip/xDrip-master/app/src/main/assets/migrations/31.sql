ALTER TABLE TransmitterData ADD COLUMN filtered_data REAL DEFAULT 0;
