ALTER TABLE Notifications ADD COLUMN bg_unclear_readings_alert BOOLEAN;
ALTER TABLE Notifications ADD COLUMN bg_missed_alerts BOOLEAN;
