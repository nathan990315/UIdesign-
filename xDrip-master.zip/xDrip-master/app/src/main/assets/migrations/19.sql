ALTER TABLE Calibration ADD COLUMN first_intercept REAL;
ALTER TABLE Calibration ADD COLUMN second_intercept REAL;
ALTER TABLE Calibration ADD COLUMN first_scale REAL;
ALTER TABLE Calibration ADD COLUMN second_scale REAL;

