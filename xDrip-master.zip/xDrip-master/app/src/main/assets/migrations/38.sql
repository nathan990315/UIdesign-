ALTER TABLE BgReadings ADD COLUMN filtered_calculated_value REAL DEFAULT 0;
