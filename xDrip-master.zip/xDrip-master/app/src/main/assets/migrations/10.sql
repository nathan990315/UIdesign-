ALTER TABLE Notifications ADD COLUMN calibration_alert BOOLEAN;
ALTER TABLE Notifications ADD COLUMN double_calibration_alert BOOLEAN;
ALTER TABLE Notifications ADD COLUMN extra_calibration_alert BOOLEAN;