ALTER TABLE Notifications ADD COLUMN bg_rise_alert BOOLEAN;
ALTER TABLE Notifications ADD COLUMN bg_fall_alert BOOLEAN;