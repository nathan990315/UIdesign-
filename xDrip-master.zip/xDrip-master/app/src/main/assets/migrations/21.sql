ALTER TABLE ActiveBluetoothDevice ADD COLUMN connected BOOLEAN;
