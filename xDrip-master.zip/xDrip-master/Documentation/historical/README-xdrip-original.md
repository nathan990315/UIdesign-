xDrip
=======
##### ** Please note this is __NOT__ a product created by or backed by Dexcom, you can check them out [here](http://dexcom.com/) **

#### Wirelessly with a Dexcom Share Receiver -- or -- Wireless xDrip bridge (No receiver!)

#### Click here for the [Main Project Page](http://stephenblackwasalreadytaken.github.io/xDrip/)


#### Access your Glucose levels from anywhere!
xDrip is ready to upload your glucose data to any [Nightscout](http://nightscout.github.io/) server for remote monitoring on just about any internet connected device!!


#### Want to learn more?? 
Jump on over to the [Wiki](https://github.com/StephenBlackWasAlreadyTaken/xDrip/wiki) for instructions and downloads!!


#### Stay Up to Date!
Follow me on twitter `@StephenIsTaken`, I will let everyone know when updates happen that you should definitely download! Updates will be rolling out fairly frequently as there is lots to do!!!


#### Want to help out?
AWESOME, let me know, put up some PRS, lets make it awesome!


#### Awesome Contributors:
(in no particular order, because they are all awesome)
* [@tzachi-dar](https://github.com/tzachi-dar) 
* [@jstevensog](https://github.com/jstevensog) 
* [@bhandfast](https://github.com/bhandfast) 
* [@LorelaiL](https://github.com/LorelaiL)
* [@syntaxerr66](https://github.com/syntaxerr66)
* [@saercnap](https://github.com/saercnap) 
* [@ktind](https://github.com/ktind)
* [Ly](http://youtu.be/YuxCUeJ9xAU)
* [Kev](http://circles-of-blue.winchcombe.org/)
* [NightScout](https://github.com/nightscout)
* Whoever else is supporting this and helping people out!!

***

<a href="http://i.imgur.com/7b18gLs.jpg"><img src="http://i.imgur.com/7b18gLs.jpg" align="center" width="600" ></a>

<a href="http://imgur.com/lFwKzRr.jpg"><img src="http://imgur.com/lFwKzRr.jpg" align="center" width="600" ></a>

***
